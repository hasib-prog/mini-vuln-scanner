"""
scanner/utils.py
────────────────
Shared utility helpers: input validation, IP resolution, severity helpers.
"""

import re
import socket
import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Regex for a bare IPv4 address
_IPV4_RE = re.compile(
    r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$"
)

# Regex for a valid hostname / domain
_HOSTNAME_RE = re.compile(
    r"^(?:[a-zA-Z0-9]"
    r"(?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?"
    r"\.)+[a-zA-Z]{2,}$"
)


def validate_target(target: str) -> tuple[bool, str]:
    """
    Validate that *target* is a sane IP or domain.
    Returns (is_valid, reason_if_invalid).
    """
    target = target.strip()

    if not target:
        return False, "Target cannot be empty."

    if len(target) > 253:
        return False, "Target is too long."

    # Strip leading http(s):// so users can paste URLs
    if target.startswith(("http://", "https://")):
        parsed = urlparse(target)
        target = parsed.hostname or target

    # IPv4 check
    m = _IPV4_RE.match(target)
    if m:
        octets = [int(m.group(i)) for i in range(1, 5)]
        if all(0 <= o <= 255 for o in octets):
            # Block RFC-1918 / loopback to reduce misuse risk
            if octets[0] == 127:
                return False, "Loopback addresses are not allowed."
            return True, ""
        return False, "IPv4 octets out of range."

    # Hostname / domain check
    if _HOSTNAME_RE.match(target):
        return True, ""

    return False, f"'{target}' is not a valid IP address or domain name."


def resolve_target(target: str) -> str | None:
    """Resolve a hostname to its IPv4 address. Returns None on failure."""
    try:
        return socket.gethostbyname(target)
    except socket.gaierror as exc:
        logger.warning("DNS resolution failed for %s: %s", target, exc)
        return None


def normalize_target(target: str) -> str:
    """Strip scheme and trailing slashes so we work with bare host."""
    target = target.strip()
    if target.startswith(("http://", "https://")):
        parsed = urlparse(target)
        target = parsed.hostname or target
    return target.rstrip("/")


# ── Severity helpers ───────────────────────────────────────────────────────────

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


def sort_vulnerabilities(vulns: list[dict]) -> list[dict]:
    """Sort a list of vulnerability dicts by severity (critical first)."""
    return sorted(vulns, key=lambda v: SEVERITY_ORDER.get(v.get("severity", "info"), 99))


def risk_score(vulns: list[dict]) -> int:
    """
    Compute a simple 0-100 risk score from a list of vulnerability findings.
    Higher = more dangerous.
    """
    weights = {"critical": 30, "high": 15, "medium": 8, "low": 3, "info": 0}
    raw = sum(weights.get(v.get("severity", "info"), 0) for v in vulns)
    return min(raw, 100)
